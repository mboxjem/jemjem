--root二进制调用模块包

--大厅聚点无后
function aa1.OnCheckedChangeListener()
  if aa1.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/Antena_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/Antena_on'")
    print("Antena On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/Antena_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/Antena_off'" )
    print("Antena Off")
  end
end

--大厅人物白色
function aa2.OnCheckedChangeListener()
  if aa2.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/norecoilOn'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/norecoilOn'")
    print("Less recoil On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/norecoilOff'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/norecoilOff'")
    print("Less recoil Off")
  end
end

--大厅除草
function aa3.OnCheckedChangeListener()
  if aa3.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/antishakeOn'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/antishakeOn'")
    print("Antishake On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/antishakeOff'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/antishakeOff'")
    print("Antishake Off")
  end
end

--大厅聚点无后
function aa4.OnCheckedChangeListener()
  if aa4.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/jumpON'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/jumpON'")
    print("No Grass On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/jumpOFF'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/jumpOFF'")
    print("No Grass Off")
  end
end

--大厅聚点无后
function aa5.OnCheckedChangeListener()
  if aa5.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/Superaimbot'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/Superaimbot'")
    print("Super AimBot On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/Superaimbot'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/Superaimbot'")
    print("Super AimBot Off")
  end
end

--大厅聚点无后
function aa6.OnCheckedChangeListener()
  if aa6.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/headshotAG_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/headshotAG_on'")
    print("Auto Headshot On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/headshotAG_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/headshotAG_off'")
    print("Auto Headshot Off")
  end
end

--大厅聚点无后
function aa7.OnCheckedChangeListener()
  if aa7.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/aimlockOn'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/aimlockOn'")
    print("AimLock On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/aimlockOff'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/aimlockOff'")
    print("AimLock Off")
  end
end

--大厅聚点无后
function aa9.OnCheckedChangeListener()
  if aa9.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/deletefog_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/deletefog_on'")
    print("No fog On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/deletefog_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/deletefog_off'")
    print("No fog Off")
  end
end

--大厅聚点无后
function aa10.OnCheckedChangeListener()
  if aa10.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/sit'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/sit'")
    print("Sit Scope On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/sitof'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/sitof'")
    print("Sit Scope Off")
  end
end

--大厅聚点无后
function aa11.OnCheckedChangeListener()
  if aa11.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/speedOn'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/speedOn'")
    print("Speed Hack On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/speedOff'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/speedOff'")
    print("Speed Hack Off")
  end
end

--大厅聚点无后
function aa12.OnCheckedChangeListener()
  if aa12.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/God'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/God'")
    print("Ipad View On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/Godoff'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/Godoff'")
    print("Ipad View Off")
  end
end

--大厅聚点无后
function aa13.OnCheckedChangeListener()
  if aa13.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/sitright_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/sitright_on'")
    print("Sit Right On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/sitright_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/sitright_off'")
    print("Sit Right Off")
  end
end

--大厅聚点无后
function aa14.OnCheckedChangeListener()
  if aa14.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/paon'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/paon'")
    print("Fast Parachute On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/paoff'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/paoff'")
    print("Fast Parachute Off")
  end
end

--麒麟联发科彩色
function ba1.OnCheckedChangeListener()
  if ba1.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/wall_660_835_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/wall_660_835_on'")
    print("Wallhack On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/wall_660_835_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/wall_660_835_off'")
    print("Wallhack Off")
  end
end

--麒麟联发科白色
function ba2.OnCheckedChangeListener()
  if ba2.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/wallhack710_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/wallhack710_on'")
    print("Wallhack 710 On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/wallhack710_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/wallhack710_off'")
    print("Wallhack 710 Off")
  end
end

--骁龙660AIE人物高清绿色
function ba3.OnCheckedChangeListener()
  if ba3.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/wallhack712_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/wallhack712_on'")
    print("Wallhack 712 On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/wallhack712_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/root/files/wallhack712_off'")
    print("Wallhack 712 Off")
  end
end

--骁龙660AIE人物高清黄色
function ba4.OnCheckedChangeListener()
  if ba4.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/wallhack835_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/wallhack835_on'")
    print("Wallhack 835 On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/wallhack835_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/wallhack835_off'")
    print("Wallhack 835 Off")
  end
end

--骁龙660AIE载具高清红色
function ba5.OnCheckedChangeListener()
  if ba5.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/wallhack845_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/wallhack845_on'")
    print("Wallhack 845 On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/wallhack845_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/wallhack845_off'")
    print("Wallhack 845 Off")
  end
end

--骁龙660AIE载具高清白色
function ba6.OnCheckedChangeListener()
  if ba6.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/wallhack855_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/wallhack855_on'")
    print("Wallhack 855 On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/wallhack855_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/wallhack855_off'")
    print("Wallhack 855 Off")
  end
end

--骁龙845/855高清人物红色
function ba7.OnCheckedChangeListener()
  if ba7.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/wallhack625_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/wallhack625_on'")
    print("Wallhack 625 On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/wallhack625_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/wallhack625_off'")
    print("Wallhack 625 Off")
  end
end

--骁龙845/855HDR人物透色
function ba8.OnCheckedChangeListener()
  if ba8.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/835or660se_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/835or660se_on'")
    print("Color Green On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/835or660se_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/835or660se_off'")
    print("Color Green Off")
  end
end

--骁龙845/855高清载具绿色
function ba9.OnCheckedChangeListener()
  if ba9.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/red660_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/red660_on'")
    print("Color Red On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/red660_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/red660_off'")
    print("Color Red Off")
  end
end

--骁龙845/855HDR载具绿色
function ba10.OnCheckedChangeListener()
  if ba10.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/bluebody_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/bluebody_on'")
    print("Color Blue On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/bluebody_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/bluebody_off'")
    print("Color Blue Off")
  end
end

--骁龙660AIE人物专用透视
function ba11.OnCheckedChangeListener()
  if ba11.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/yellowbody_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/yellowbody_on'")
    print("Color Yellow On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/yellowbody_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/yellowbody_off'")
    print("Color Yellow Off")
  end
end

--骁龙710/845/855人物透视
function ba12.OnCheckedChangeListener()
  if ba12.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/Black_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/Black_on'")
    print("Color Black On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/Black_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/Black_off'")
    print("Color Black Off")
  end
end

--骁龙710/845/855人物透视
function ba13.OnCheckedChangeListener()
  if ba13.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/yellow660_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/yellow660_on'")
    print("Color Yellow2 On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/yellow660_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/yellow660_off'")
    print("Color Yellow2 Off")
  end
end

--骁龙710/845/855人物透视
function ba14.OnCheckedChangeListener()
  if ba14.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/mix660_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/mix660_on'")
    print("Color Mix On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/mix660_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/mix660_off'")
    print("Color Mix Off")
  end
end

--骁龙710/845/855人物透视
function ba15.OnCheckedChangeListener()
  if ba15.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/625_shangse_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/625_shangse_on'")
    print("Color 625 On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/625_shangse_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/625_shangse_off'")
    print("Color 625 Off")
  end
end

--骁龙710/845/855人物透视
function ba16.OnCheckedChangeListener()
  if ba16.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/710_shangse_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/710_shangse_on'")
    print("Color 710 On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/710_shangse_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/710_shangse_off'")
    print("Color 710 Off")
  end
end

--骁龙710/845/855人物透视
function ba17.OnCheckedChangeListener()
  if ba17.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/710or845or855se_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/710or845or855se_on'")
    print("Color 710/845/855 On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/710or845or855se_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/710or845or855se_off'")
    print("Color 710/845/855 Off")
  end
end

--骁龙710/845/855人物透视
function ba18.OnCheckedChangeListener()
  if ba18.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/835_shangse_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/835_shangse_on'")
    print("Color 835 On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/835_shangse_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/835_shangse_off'")
    print("Color 835 Off")
  end
end

--骁龙710/845/855人物透视
function ba19.OnCheckedChangeListener()
  if ba19.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/845_shangse_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/845_shangse_on'")
    print("Color 845 On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/845_shangse_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/845_shangse_off'")
    print("Color 845 Off")
  end
end

--骁龙710/845/855人物透视
function ba20.OnCheckedChangeListener()
  if ba20.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/855_shangse_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/855_shangse_on'")
    print("Color 855 On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/855_shangse_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/855_shangse_off'")
    print("Color 855 Off")
  end
end

--全图除雾
function ba21.OnCheckedChangeListener()
  if ba21.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/Fix_Blink'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/Fix_Blink'")
    print("Wallhack Fix Blink On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/Fix_Blink'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/Fix_Blink'")
    print("Wallhack Fix Blink Off")
  end
end

--人物加速
function ba22.OnCheckedChangeListener()
  if ba22.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/walliten_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/walliten_on'")
    print("Wallhack Itens On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/walliten_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/walliten_off'")
    print("Wallhack Itens Off")
  end
end

--人物加速
function ca1.OnCheckedChangeListener()
  if ca1.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/deletefog_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/deletefog_on'")
    print("Delete Fog On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/deletefog_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/deletefog_off'")
    print("Delete Fog Off")
  end
end

--人物加速
function ca2.OnCheckedChangeListener()
  if ca2.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/removeobjectOn'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/removeobjectOn'")
    print("Remove Object On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/removeobjectOff'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/removeobjectOff'")
    print("Remove Object Off")
  end
end

--人物加速
function ca3.OnCheckedChangeListener()
  if ca3.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/blackskyOn'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/blackskyOn'")
    print("Black Sky On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/blackskyOff'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/blackskyOff'")
    print("Black Sky Off")
  end
end

--人物加速
function ca4.OnCheckedChangeListener()
  if ca4.checked then
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/wall_on'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/wall_on'")
    print("No Grass On")
   else
    os.execute("su -c 'chmod 777 /data/data/com.xlm.myths/files/root/wall_off'")
    Runtime.getRuntime().exec("su -c '/data/data/com.xlm.myths/files/root/wall_off'")
    print("No Grass Off")
  end
end

