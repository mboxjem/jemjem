--root悬浮窗控件布局

-------------------------分割线

--悬浮球控件布局

minlay1={
  LinearLayout;
  layout_width="62dp";
  layout_height="62dp";
  {
    CardView;
    layout_width="50dp";
    background="#0066ccff";
    layout_margin="6dp";
    CardElevation="3dp";
    layout_height="50dp";
    radius=70;
    id="Win_minWindow1";
    {
      ImageView;
      layout_width="65dp";
      src="icon.png";
      layout_height="78dp";
    };
  };
};

-------------------------分割线

--悬浮窗控件布局

winlay1={
  LinearLayout,
  layout_width="-1",
  layout_height="-1",
  {
    CardView,
    id="win_mainview1",
    layout_width="600", --设置悬浮窗宽度为自动调整
    layout_height="800"; --设置悬浮窗长度为自动填充
    layout_margin="5dp",
    CardElevation="5dp",
    radius=40, --设置悬浮窗圆角
    {
      LinearLayout;
      orientation="vertical";
      background="#000000",--中间背景

      {
        LinearLayout;

        {
          LinearLayout;
          orientation="horizontal";
          layout_height="100";
          layout_width="-1";
          background="#FF0090FF";
          background="#22FFFFFF",--标题颜色

          {
            ImageView,
            layout_width="100",
            layout_height="100",
            scaleType="centerCrop",
            padding="3dp",
            src="assets/rx1.png",
            layout_gravity="left";
            ColorFilter="#0",
            onClick="changeWindow1",
          },

          {
            TextView;
            text="Myths Team";
            id="win_move1",
            layout_width="400",
            layout_height="100",
            gravity="center",
            textSize="15";
            textColor="#ffff0000";
          },

          {
            ImageView,
            layout_width="100",
            layout_height="100",
            scaleType="centerCrop",
            padding="3dp",
            src="assets/rx4.png",
            layout_gravity="left";
            ColorFilter="#0",
            onClick="close1",
          },
        };
      };

      {
        LinearLayout;
        layout_height="0.1%h";
        layout_width="100%w";
        background="#292929",}; --绘制一条线

      {
        LinearLayout;
        orientation="horizontal";
        layout_height="100";
        layout_width="-1";
        --  background="#FF0090FF";
        background="#22FFFFFF",--标题颜色

        {
          Button;
          id="大厅1";
          layout_height="-1";
          layout_width="-1";
          background="#000000";
          text="Hack";
          textColor="#ffff00ff";
          layout_weight="3";
          --  background="#ffffff", --大厅功能颜色
        };

        {
          Button;
          id="落地1";
          layout_height="-1";
          layout_width="-1";
          background="#000000";
          text="Wall";
          textColor="#ffff00ff";
          layout_weight="3";
          --  background="#ffffff", --大厅功能颜色
        };
        {
          Button;
          id="落地2";
          layout_height="-1";
          layout_width="-1";
          background="#000000";
          text="Visual";
          textColor="#ffff00ff";
          layout_weight="3";
          --  background="#ffffff", --大厅功能颜色
        };
      };

      {
        LinearLayout;
        layout_width="-1";
        background="#22FFFFFF",

        {
          TextView;
          id="jd1";
          background="#292929";
          layout_height="3dp";
          layout_width="28%w";
        };
      };

      {
        PageView,
        id="pg1",
        layout_width="fill",
        layout_height="fill",
        pages={

          ----------界面切割线----------

          {
            LinearLayout;
            orientation="vertical";

            {LinearLayout;
              layout_height="0.1%h";
              layout_width="100%w";
              background="#292929",}; --绘制一条线

            {
              ScrollView;

              {
                LinearLayout;
                layout_height="-1";
                layout_width="-1";
                orientation="vertical";

                {
                  LinearLayout;
                  id="_drawer_header";
                  layout_height="-2";
                  layout_width="-1";
                  orientation="vertical";

                  {
                    LinearLayout;
                    layout_height="-1";
                    layout_width="-1";
                    --padding="16dp";
                    orientation="vertical";

                    {
                      Switch;
                      id="aa1";
                      textColor="#ffff00ff";
                      text="    Antenna                                                                                                 ";

                    };

                    {
                      Switch;
                      id="aa2";
                      textColor="#ffff00ff";
                      text="    Less Recoil                                                                                                 ";
                    };

                    {
                      Switch;
                      id="aa3";
                      textColor="#ffff00ff";
                      text="    Anti Shake                                                                            ";
                    };

                    {
                      Switch;
                      id="aa4";
                      textColor="#ffff00ff";
                      text="    High Jump                                                                              ";
                    };
                    {
                      Switch;
                      id="aa5";
                      textColor="#ffff00ff";
                      text="    Aimbot                                                                            ";
                    };
                    {
                      Switch;
                      id="aa6";
                      textColor="#ffff00ff";
                      text="    Auto HeadShot                                                                            ";
                    };
                    {
                      Switch;
                      id="aa7";
                      textColor="#ffff00ff";
                      text="    AimLock                                                                            ";
                    };

                    {
                      Switch;
                      id="aa9";
                      textColor="#ffff00ff";
                      text="    No Fog                                                                           ";
                    };
                    {
                      Switch;
                      id="aa10";
                      textColor="#ffff00ff";
                      text="    Sit Scope                                                                           ";
                    };
                    {
                      Switch;
                      id="aa11";
                      textColor="#ffff00ff";
                      text="    Speed Hack                                                                           ";
                    };
                    {
                      Switch;
                      id="aa12";
                      textColor="#ffff00ff";
                      text="    Ipad View                                                                          ";
                    };
                    {
                      Switch;
                      id="aa13";
                      textColor="#ffff00ff";
                      text="    Sit Right                                                                          ";
                    };
                    {
                      Switch;
                      id="aa14";
                      textColor="#ffff00ff";
                      text="    Fast Parachute                                                                          ";
                    };

                  };
                };
              };
            };
          };

          ----------界面切割线----------

          {
            LinearLayout;
            orientation="vertical";

            {LinearLayout;
              layout_height="0.1%h";
              layout_width="100%w";
              background="#292929",}; --绘制一条线

            {
              ScrollView;

              {
                LinearLayout;
                layout_height="-1";
                layout_width="-1";
                orientation="vertical";

                {
                  LinearLayout;
                  id="_drawer_header";
                  layout_height="-2";
                  layout_width="-1";
                  orientation="vertical";

                  {
                    LinearLayout;
                    layout_height="-1";
                    layout_width="-1";
                    --padding="16dp";
                    orientation="vertical";

                    {
                      Switch;
                      id="ba1";
                      textColor="#ffff00ff";
                      text="    Wallhack 660/835                                                                                ";
                    };

                    {
                      Switch;
                      id="ba2";
                      textColor="#ffff00ff";
                      text="    Wallhack 710                                                                                ";
                    };

                    {
                      Switch;
                      id="ba3";
                      text="    Wallhack 712                                                                                ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba4";
                      text="    Wallhack 835                                                                                ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba5";
                      text="    Wallhack 845                                                                                ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba6";
                      text="    Wallhack 855                                                                            ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba7";
                      text="    Wallhack 625                                                                       ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba8";
                      text="    Color Green                                                                              ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba9";
                      text="    Color Red                                                                               ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba10";
                      text="    Color Blue                                                                                ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba11";
                      text="    Color Yellow                                                                                ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba12";
                      text="    Color Black                                                                       ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba13";
                      text="    Color Yellow 2                                                                       ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba14";
                      text="    Color Mix                                                                       ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba15";
                      text="    Color 625                                                                             ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba16";
                      text="    Color 710                                                                       ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba17";
                      text="    Color 710/845/855                                                                             ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba18";
                      text="    Color 835                                                                       ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba19";
                      text="    Color 845                                                                             ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba20";
                      text="    Color 855                                                                       ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba21";
                      text="    Wallhack Fix Blink                                                                             ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ba22";
                      text="    Wallhack Itens                                                                                ";
                      textColor="#ffff00ff";
                    };



                  };
                };
              };
            };
          };
          {
            LinearLayout;
            orientation="vertical";

            {LinearLayout;
              layout_height="0.1%h";
              layout_width="100%w";
              background="#292929",}; --绘制一条线

            {
              ScrollView;

              {
                LinearLayout;
                layout_height="-1";
                layout_width="-1";
                orientation="vertical";

                {
                  LinearLayout;
                  id="_drawer_header";
                  layout_height="-2";
                  layout_width="-1";
                  orientation="vertical";

                  {
                    LinearLayout;
                    layout_height="-1";
                    layout_width="-1";
                    --padding="16dp";
                    orientation="vertical";

                    {
                      Switch;
                      id="ca1";
                      textColor="#ffff00ff";
                      text="    Delete Fog                                                                                ";
                    };

                    {
                      Switch;
                      id="ca2";
                      textColor="#ffff00ff";
                      text="    Remove Object                                                                                ";
                    };

                    {
                      Switch;
                      id="ca3";
                      text="    Black Sky                                                                                ";
                      textColor="#ffff00ff";
                    };

                    {
                      Switch;
                      id="ca4";
                      text="    No Grass (Lobby)                                                                              ";
                      textColor="#ffff00ff";
                    };

                  };
                };
              };
            };
          };

          ----------界面切割线----------

        };
      };
    };
  };
}
