--免ROOT悬浮窗控件布局

-------------------------分割线

--悬浮球控件布局

minlay={
  LinearLayout;
  layout_width="62dp";
  layout_height="62dp";
  {
    CardView;
    layout_width="50dp";
    background="#0066ccff";
    layout_margin="6dp";
    CardElevation="3dp";
    layout_height="50dp";
    radius=70;
    id="Win_minWindow";
    {
      ImageView;
      layout_width="50dp";
      src="icon.png";
      layout_height="50dp";
    };
  };
};

-------------------------分割线

--悬浮窗控件布局

winlay={
  LinearLayout,
  layout_width="-1",
  layout_height="-1",
  {
    CardView,
    id="win_mainview",
    layout_width="600", --设置悬浮窗宽度为自动调整
    layout_height="700"; --设置悬浮窗长度为自动填充
    layout_margin="5dp",
    CardElevation="5dp",
    radius=40, --设置悬浮窗圆角
    {
      LinearLayout;
      orientation="vertical";
      background="assets/rx2.png",--中间背景

      {
        LinearLayout;

        {
          LinearLayout;
          orientation="horizontal";
          layout_height="100";
          layout_width="-1";
          background="#FF0090FF";
          background="#22FFFFFF",--标题颜色

          {
            ImageView,
            layout_width="100",
            layout_height="100",
            scaleType="centerCrop",
            padding="3dp",
            src="assets/rx1.png",
            layout_gravity="left";
            ColorFilter="#0",
            onClick="changeWindow",
          },

          {
            TextView;
            text="Myths Team";
            id="win_move",
            layout_width="400",
            layout_height="100",
            gravity="center",
            textSize="15";
            textColor="#ff0000ff";
          },

          {
            ImageView,
            layout_width="100",
            layout_height="100",
            scaleType="centerCrop",
            padding="3dp",
            src="assets/rx4.png",
            layout_gravity="left";
            ColorFilter="#0",
            onClick="close",
          },
        };
      };

      {
        LinearLayout;
        layout_height="0.1%h";
        layout_width="100%w";
        background="#292929",}; --绘制一条线

      {
        LinearLayout;
        orientation="horizontal";
        layout_height="100";
        layout_width="-1";
        --  background="#FF0090FF";
        background="#22FFFFFF",--标题颜色

        {
          Button;
          id="大厅";
          layout_height="-1";
          layout_width="-1";
          background="#00ffffff";
          text="Menu 1";
          textColor="#ffff00ff";
          layout_weight="3";
          --  background="#ffffff", --大厅功能颜色
        };

        {
          Button;
          id="落地";
          layout_height="-1";
          layout_width="-1";
          background="#00ffffff";
          text="Menu 2";
          textColor="#ff00ffff";
          layout_weight="3";
          --  background="#ffffff", --大厅功能颜色
        };
      };

      {
        LinearLayout;
        layout_width="-1";
        background="#22FFFFFF",

        {
          TextView;
          id="jd";
          background="#292929";
          layout_height="3dp";
          layout_width="28%w";
        };
      };

      {
        PageView,
        id="pg",
        layout_width="fill",
        layout_height="fill",
        pages={

          ----------界面切割线----------

          {
            LinearLayout;
            orientation="vertical";

            {LinearLayout;
              layout_height="0.1%h";
              layout_width="100%w";
              background="#292929",}; --绘制一条线

            {
              ScrollView;

              {
                LinearLayout;
                layout_height="-1";
                layout_width="-1";
                orientation="vertical";

                {
                  LinearLayout;
                  id="_drawer_header";
                  layout_height="-2";
                  layout_width="-1";
                  orientation="vertical";

                  {
                    LinearLayout;
                    layout_height="-1";
                    layout_width="-1";
                    --padding="16dp";
                    orientation="vertical";

                    {
                      Switch;
                      id="a1";
                      textColor="#ffff00ff";
                      text="    大厅聚点无后(大厅)                                                                                                   ";
                    };

                    {
                      Switch;
                      id="a2";
                      textColor="#ffff00ff";
                      text="    通用白色(训练场开)                                                                                                    ";
                    };

                    {
                      Switch;
                      id="a3";
                      textColor="#ffff00ff";
                      text="    大厅全图除草(大厅)                                                                               ";
                    };

                    {
                      Switch;
                      id="a4";
                      textColor="#ffff00ff";
                      text="    备用大厅无后(大厅)                                                                                ";
                    };

                  };
                };
              };
            };
          };

          ----------界面切割线----------

          {
            LinearLayout;
            orientation="vertical";

            {LinearLayout;
              layout_height="0.1%h";
              layout_width="100%w";
              background="#292929",}; --绘制一条线

            {
              ScrollView;

              {
                LinearLayout;
                layout_height="-1";
                layout_width="-1";
                orientation="vertical";

                {
                  LinearLayout;
                  id="_drawer_header";
                  layout_height="-2";
                  layout_width="-1";
                  orientation="vertical";

                  {
                    LinearLayout;
                    layout_height="-1";
                    layout_width="-1";
                    --padding="16dp";
                    orientation="vertical";

                    {
                      Switch;
                      id="b1";
                      textColor="#ff00ffff";
                      text="    麒麟联发科彩色                                                                                ";
                    };

                    {
                      Switch;
                      id="b2";
                      textColor="#ff00ffff";
                      text="    麒麟联发科白色                                                                                ";
                    };

                    {
                      Switch;
                      id="b3";
                      text="    660AIE高清人物绿                                                                                ";
                      textColor="#ff00ffff";
                    };

                    {
                      Switch;
                      id="b4";
                      text="    660AIE高清人物黄                                                                                ";
                      textColor="#ff00ffff";
                    };

                    {
                      Switch;
                      id="b5";
                      text="    660AIE高清载具红                                                                                ";
                      textColor="#ff00ffff";
                    };

                    {
                      Switch;
                      id="b6";
                      text="    660AIE高清载具白                                                                                ";
                      textColor="#ff00ffff";
                    };

                    {
                      Switch;
                      id="b18";
                      text="    骁龙710高清载具红                                                                               ";
                      textColor="#ff00ffff";
                    };

                    {
                      Switch;
                      id="b19";
                      text="    骁龙710高清人物黄色                                                                               ";
                      textColor="#ff00ffff";
                    };

                    {
                      Switch;
                      id="b7";
                      text="    845/855高清人物红色                                                                                ";
                      textColor="#ff00ffff";
                    };

                    {
                      Switch;
                      id="b8";
                      text="    845/855HDR人物透色                                                                                ";
                      textColor="#ff00ffff";
                    };

                    {
                      Switch;
                      id="b9";
                      text="    845/855高清载具绿色                                                                                ";
                      textColor="#ff00ffff";
                    };

                    {
                      Switch;
                      id="b10";
                      text="    845/855HDR载具绿色                                                                                ";
                      textColor="#ff00ffff";
                    };

                    {
                      Switch;
                      id="b11";
                      text="    骁龙660AIE专用透视                                                                                ";
                      textColor="#ff00ffff";
                    };

                    {
                      Switch;
                      id="b12";
                      text="    骁龙710/845/855透视                                                                                ";
                      textColor="#ff00ffff";
                    };

                    {
                      Switch;
                      id="b13";
                      text="    全机通用地图除雾                                                                               ";
                      textColor="#ff00ffff";
                    };

                    {
                      Switch;
                      id="b14";
                      text="    全机通用人物加速                                                                               ";
                      textColor="#ff00ffff";
                    };

                    {
                      Switch;
                      id="b15";
                      text="    全机通用秒开倍镜                                                                               ";
                      textColor="#ff00ffff";
                    };

                    {
                      Switch;
                      id="b16";
                      text="    红点机瞄变六倍镜                                                                               ";
                      textColor="#ff00ffff";
                    };

                    {
                      Switch;
                      id="b17";
                      text="    通用全枪范围打击                                                                               ";
                      textColor="#ff00ffff";
                    };

                  };
                };
              };
            };
          };

          ----------界面切割线----------

        };
      };
    };
  };
}