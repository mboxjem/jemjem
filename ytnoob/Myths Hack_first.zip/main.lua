require "import" --开始导入
import "android.app.*"
import "android.os.*"
import "android.widget.*" --导入widget控件
import "android.view.*"
import "AndLua" --导入Andlua中文函数模块
import "http"
import "android.content.Context"
import "android.content.Intent"
import "android.net.Uri"
import "android.provider.Settings"
import "min"--导入免root悬浮窗控件
import "min1"--导入root悬浮窗控件
import "layout" --导入布局
activity.setContentView(loadlayout(layout)) --开始读取并加载布局页面

do
ROOT悬浮窗=activity.getSystemService(Context.WINDOW_SERVICE) --获取窗口管理器
HasFocus=false --是否有焦点
wmParams =WindowManager.LayoutParams() --对象
wmParams.type =WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY --设置悬浮窗方式
import "android.graphics.PixelFormat" --导入
wmParams.format =PixelFormat.RGBA_8888 --设置背景
wmParams.flags=WindowManager.LayoutParams().FLAG_NOT_FOCUSABLE--焦点设置
wmParams.gravity = Gravity.LEFT| Gravity.TOP --重力设置
wmParams.x = activity.getWidth()/6
wmParams.y = activity.getHeight()/5
wmParams.width =WindowManager.LayoutParams.WRAP_CONTENT
wmParams.height =WindowManager.LayoutParams.WRAP_CONTENT
if Build.VERSION.SDK_INT >= Build.VERSION_CODES.M&&!Settings.canDrawOverlays(this) then
  print("There are no floating window permissions, please open the permissions")
  intent=Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
  activity.startActivityForResult(intent, 100)
  os.exit()
 else
mainWindow1=loadlayout(winlay1)
minWindow1=loadlayout(minlay1)
end

function close1(v1) --关闭
  HasLaunch1=false
  ROOT悬浮窗.removeView(mainWindow1)
  --wmParams=nil
  --mainWindow=nil
  --ROOT悬浮窗=nil
end

isMax=true --状态

function changeWindow1()
  if isMax==false then
    isMax=true
    ROOT悬浮窗.removeView(minWindow1)
    ROOT悬浮窗.addView(mainWindow1,wmParams)
   else
    isMax=false
    ROOT悬浮窗.removeView(mainWindow1)
    ROOT悬浮窗.addView(minWindow1,wmParams)
  end
end

function Win_minWindow1.onClick(v)
  changeWindow1()
end

function Win_minWindow1.OnTouchListener(v1,event) --移动
  if event.getAction()==MotionEvent.ACTION_DOWN then
    firstX=event.getRawX()
    firstY=event.getRawY()
    wmX=wmParams.x
    wmY=wmParams.y
   elseif event.getAction()==MotionEvent.ACTION_MOVE then
    wmParams.x=wmX+(event.getRawX()-firstX)
    wmParams.y=wmY+(event.getRawY()-firstY)
    ROOT悬浮窗.updateViewLayout(minWindow1,wmParams)
   elseif event.getAction()==MotionEvent.ACTION_UP then
    --changeWindow()
  end
  return false
end

function win_move1.OnTouchListener(v1,event) --移动
  if event.getAction()==MotionEvent.ACTION_DOWN then
    firstX=event.getRawX()
    firstY=event.getRawY()
    wmX=wmParams.x
    wmY=wmParams.y
   elseif event.getAction()==MotionEvent.ACTION_MOVE then
    wmParams.x=wmX+(event.getRawX()-firstX)
    wmParams.y=wmY+(event.getRawY()-firstY)
    ROOT悬浮窗.updateViewLayout(mainWindow1,wmParams)
   elseif event.getAction()==MotionEvent.ACTION_UP then
  end
  return true
end

大厅1.onClick=function() --功能点击选择
  pg1.showPage(0)
end
落地1.onClick=function()
  pg1.showPage(1)
end
落地2.onClick=function()
  pg1.showPage(2)
end

pg1.addOnPageChangeListener{ --功能滑动选择
  onPageScrolled=function(a,b,c)
    --在被滑动的时候不断调用
    -- print(a,b,c)
    jd1.setX(activity.getWidth()/7.0*(b+a))
  end,
  onPageSelected=function(page)
    --页面被选择 也就是到哪个页面时触发
    --print(page)
  end,
  onPageScrollStateChanged=function(state)
    --监听操作状态 有0,1,2
    --print(state)
  end,
}

--获取天气、时间、所在城市
天气网链接="https://m.tianqi.com/"
中国天气网链接="https://m.weather.com.cn/"
天气源=1 --1天气网，2中国天气网
--天气网的天气获取
Http.get(天气网链接,nil,"utf8",nil,function(code,content,cookie,header)
  if(code==200 and content)then
    定位城市=content:match("<text>(.-)</text>")
    湿度=content:match('<span class="b2"><i></i>湿度(.-)</span')
    空气质量=content:match('<div class="info"><span class="b1"><i></i>(.-)</span')
    风力风向=content:match('<span class="b3"><i></i>(.-)</span>')
    度数=content:match('<dd class="now">(.-)<i>')
    详细=content:match('<dd class="txt">(.-)</dd>')
    天气图标=content:match('<dt><img src="(.-)"></dt>')
    天气icon.setImageBitmap(loadbitmap("https://m.tianqi.com/"..天气图标))
    温度text.text=度数.."℃"
    湿度text.text="Humidity"..湿度
    天气icon.setColorFilter(0x00000000)
   else
    print("⛅Network abnormality, unable to get weather temperature information⛅")
  end
end)

--点击时间可刷新当前时间（线程可能有延迟）
function 时间()
  hb()
end
十二小时制=1
asp.setText(os.date("%H:%M:%S"))
if 十二小时制==0 or 十二==0 then
  if tonumber(os.date("%H"))==tonumber("24") then
    asp.setText(os.date("00:%M"))
   elseif tonumber(os.date("%H"))==tonumber("23") then
    asp.setText(os.date("11:%M"))
   elseif tonumber(os.date("%H"))==tonumber("22") then
    asp.setText(os.date("10:%M"))
   elseif tonumber(os.date("%H"))==tonumber("21") then
    asp.setText(os.date("9:%M"))
   elseif tonumber(os.date("%H"))==tonumber("20") then
    asp.setText(os.date("8:%M"))
   elseif tonumber(os.date("%H"))==tonumber("19") then
    asp.setText(os.date("7:%M"))
   elseif tonumber(os.date("%H"))==tonumber("18") then
    asp.setText(os.date("6:%M"))
   elseif tonumber(os.date("%H"))==tonumber("17") then
    asp.setText(os.date("5:%M"))
   elseif tonumber(os.date("%H"))==tonumber("16") then
    asp.setText(os.date("4:%M"))
   elseif tonumber(os.date("%H"))==tonumber("15") then
    asp.setText(os.date("3:%M"))
   elseif tonumber(os.date("%H"))==tonumber("14") then
    asp.setText(os.date("2:%M"))
   elseif tonumber(os.date("%H"))==tonumber("13") then
    asp.setText(os.date("1:%M"))
  end
end

function hb(十二)
  asp.setText(os.date("%H:%M:%S"))
  --检测时间并设置时间段
  if tonumber(os.date("%H"))>=tonumber("24") then
    asp3.setText("Midnight")
   elseif tonumber(os.date("%H"))>=tonumber("19") then
    asp3.setText("In the evening")
   elseif tonumber(os.date("%H"))>=tonumber("17") then
    asp3.setText("Evening")
   elseif tonumber(os.date("%H"))>=tonumber("14") then
    asp3.setText("In the afternoon")
   elseif tonumber(os.date("%H"))>=tonumber("12") then
    asp3.setText("Noon")
   elseif tonumber(os.date("%H"))>=tonumber("10") then
    asp3.setText("Morning")
   elseif tonumber(os.date("%H"))>=tonumber("7") then
    asp3.setText("Morning")
   elseif tonumber(os.date("%H"))<=tonumber("5") then
    asp3.setText("Early morning")
  end
  if asp2.text:find"00" then
    asp.setText(os.date("%H:%M:%S"))
    if 十二小时制==0 or 十二==0 then
      if tonumber(os.date("%H"))==tonumber("24") then
        asp.setText(os.date("00:%M"))
       elseif tonumber(os.date("%H"))==tonumber("23") then
        asp.setText(os.date("11:%M"))
       elseif tonumber(os.date("%H"))==tonumber("22") then
        asp.setText(os.date("10:%M"))
       elseif tonumber(os.date("%H"))==tonumber("21") then
        asp.setText(os.date("9:%M"))
       elseif tonumber(os.date("%H"))==tonumber("20") then
        asp.setText(os.date("8:%M"))
       elseif tonumber(os.date("%H"))==tonumber("19") then
        asp.setText(os.date("7:%M"))
       elseif tonumber(os.date("%H"))==tonumber("18") then
        asp.setText(os.date("6:%M"))
       elseif tonumber(os.date("%H"))==tonumber("17") then
        asp.setText(os.date("5:%M"))
       elseif tonumber(os.date("%H"))==tonumber("16") then
        asp.setText(os.date("4:%M"))
       elseif tonumber(os.date("%H"))==tonumber("15") then
        asp.setText(os.date("3:%M"))
       elseif tonumber(os.date("%H"))==tonumber("14") then
        asp.setText(os.date("2:%M"))
       elseif tonumber(os.date("%H"))==tonumber("13") then
        asp.setText(os.date("1:%M"))
      end
    end
  end
  if tonumber(os.date("%S"))<03 then
    --print("less than 02")
    if 十二小时制==0 or 十二==0 then
      if tonumber(os.date("%H"))==tonumber("24") then
        asp.setText(os.date("00:%M"))
       elseif tonumber(os.date("%H"))==tonumber("23") then
        asp.setText(os.date("11:%M"))
       elseif tonumber(os.date("%H"))==tonumber("22") then
        asp.setText(os.date("10:%M"))
       elseif tonumber(os.date("%H"))==tonumber("21") then
        asp.setText(os.date("9:%M"))
       elseif tonumber(os.date("%H"))==tonumber("20") then
        asp.setText(os.date("8:%M"))
       elseif tonumber(os.date("%H"))==tonumber("19") then
        asp.setText(os.date("7:%M"))
       elseif tonumber(os.date("%H"))==tonumber("18") then
        asp.setText(os.date("6:%M"))
       elseif tonumber(os.date("%H"))==tonumber("17") then
        asp.setText(os.date("5:%M"))
       elseif tonumber(os.date("%H"))==tonumber("16") then
        asp.setText(os.date("4:%M"))
       elseif tonumber(os.date("%H"))==tonumber("15") then
        asp.setText(os.date("3:%M"))
       elseif tonumber(os.date("%H"))==tonumber("14") then
        asp.setText(os.date("2:%M"))
       elseif tonumber(os.date("%H"))==tonumber("13") then
        asp.setText(os.date("1:%M"))
      end
    end
  end
end

function 刷新()
  require("import")
  while true do
    Thread.sleep(100)
    call("时间")
  end
end
thread(刷新)

import "android.animation.ObjectAnimator"--导入特效包
function 水珠动画(控件,时间)
  ObjectAnimator().ofFloat(控件,"scaleX",{1,.8,1.3,.9,1}).setDuration(时间).start()
  ObjectAnimator().ofFloat(控件,"scaleY",{1,.8,1.3,.9,1}).setDuration(时间).start()
end

控件圆角(ROOT模式,0xffffffff,70)
控件圆角(启动游戏,0xffffffff,70)
控件圆角(加入QQ群,0xffffffff,70)

ROOT模式.onClick=function() --功能界面
  水珠动画(ROOT模式,300)
  function checkRoot() --检查是否获取root权限
    local root,exit,numb=os.execute("su")
    if root==true then
      print("Root permissions and is ready for use 💯") --已授予root权限的结果提示
      return
     else
      print("Cannot use root without gaining root permissions❌") --未授予root权限或者没有root权限的结果提示
      return
    end
  end
  print(checkRoot())
  os.execute("su") --申请root权限
  function RX0() --判断手机是否支持悬浮窗权限
    if (Build.VERSION.SDK_INT >= 23 and not Settings.canDrawOverlays(this)) then
      return false
     elseif Build.VERSION.SDK_INT < 23 then
      print("Sorry your phone does not support opening floating windows❌")
      return nil
     else
      return true
    end
  end

  if RX0() then --条件满足弹出请求悬浮窗提示
   else
    AlertDialog.Builder(this)
    .setTitle("Cannot open floating window")
    .setMessage("Need to give application floating window permission to open the function interface")
    .setPositiveButton("Click Authorize floating window permissions",{onClick=function(v)
        intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
        intent.setData(Uri.parse("package:" .. activity.getPackageName()));
        activity.startActivityForResult(intent, 100);
      end})
    .show()
  end

  if HasLaunch1==true then --跳转到悬浮窗权限授权界面
    return
   else
    if Settings.canDrawOverlays(activity) then
     else
      intent=Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION");
      intent.setData(Uri.parse("package:" .. this.getPackageName()));
      this.startActivity(intent);
    end
    HasLaunch1=true
    local ret={pcall(function() ROOT悬浮窗.addView(mainWindow1,wmParams) end)}
    if ret[1]==false then
    end
  end
end

启动游戏.onClick=function() --打开游戏
  水珠动画(启动游戏,300)
  print("GO TO PUBG MOBILE . . .")
  ycpd=true
  packageName="com.tencent.ig",
  import "android.content.Intent"
  import "android.content.pm.PackageManager"
  manager = activity.getPackageManager()
  open = manager.getLaunchIntentForPackage(packageName)
  this.startActivity(open)
  os.remove('/storage/emulated/0/Android/data/com.tencent.ig/cache/GCloud.ini')
  os.remove('/sdcard/Android/data/com.tencent.ig/cache/GCloud.ini')
  os.remove('/sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs')
end

加入QQ群.onClick=function() --加入QQ群
  水珠动画(加入QQ群,300)
  function RX1() --判断手机是否支持打开此功能
    if (Build.VERSION.SDK_INT >= 23 and not Settings.canDrawOverlays(this)) then
      return false
     elseif Build.VERSION.SDK_INT < 23 then
      print("抱歉你的手机不支持打开此功能❌")
    end
  end

  if RX1() then --条件满足跳转进入游戏
   else
    if pcall(function() activity.getPackageManager().getPackageInfo("com.tencent.igce",0) end) then --判断游戏是否已经安装
      ycpd=true
      packageName="com.tencent.igce", --设置要打开游戏的包名
      import "android.content.pm.PackageManager" --开始导入游戏包名
      manager = activity.getPackageManager()
      open = manager.getLaunchIntentForPackage(packageName)
      this.startActivity(open) --打开游戏
     else
      print("🔥Welcome to Telegram Myths Team Hack🔥")
      intent = Intent("android.intent.action.VIEW")
      intent .setData(Uri.parse( "http://t.me/mythsteamhack")) --设置跳转下载的链接
      this.startActivity(intent)
    end
  end
end



-------------------------------------------------------我是分割线

import "root"--导入root二进制调用模块包
end 