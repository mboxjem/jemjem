--设置程序相关信息及使用权限

appname="Myths Hack" --设置应用名称
appver="1.0" --设置应用版本
packagename="com.xlm.myths" --设置应用包名
theme="Theme_DeviceDefault_Light_NoActionBar" --设置主题
developer="小奶猫" --设置开发者名字
description="xlm" --设置类型
debugmode=true --设置调试方式
user_permission={ --设置应用获取手机上的权限
  "ACCESS_NETWORK_STATE", --允许应用查看网络连接的相关信息
  "CHANGE_WIFI_STATE", --运行应用查看wifi连接以及更改wifi配置
  "INTERNET", --允许应用创建网络套接字和使用自定义网络协议
  "READ_EXTERNAL_STORAGE", --允许应用读取您USB存储设备中的内容
  "READ_PHONE_STATE", --允许应用获取手机号码、IMEI、IMSI权限
  "SYSTEM_ALERT_WINDOW", --允许应用可显示在其他应用上方或屏幕的其它部分
  "WRITE_EXTERNAL_STORAGE", --允许应用写入内容到您的USB设备
  "WRITE_SETTINGS" --允许应用修改系统的设置数据
}
